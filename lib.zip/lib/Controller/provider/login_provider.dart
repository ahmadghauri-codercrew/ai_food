import 'package:flutter/foundation.dart';

class FavouriteProvider extends ChangeNotifier {}

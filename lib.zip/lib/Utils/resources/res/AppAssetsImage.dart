class AppAssetsImage {
  static final String appLogo = "assets/images/logo.png";
  static const String profile_text_background = "assets/images/profile_text_background.png";
}

class AppAssetsImages {
  static const String appLogo = "assets/images/logo.png";
}

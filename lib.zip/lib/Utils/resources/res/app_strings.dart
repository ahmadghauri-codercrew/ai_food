class AppStrings {
  //Start_screen.dart Dialogs
  static const String textDialog = "Support Local\nVendors";
}

class RecipesParameterClass{
  final String parameter;
  bool isChecked;

  RecipesParameterClass({required this.parameter, this.isChecked = false});
}
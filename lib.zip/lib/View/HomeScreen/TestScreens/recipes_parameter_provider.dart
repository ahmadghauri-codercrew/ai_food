import 'package:ai_food/View/HomeScreen/TestScreens/model_recipe.dart';
import 'package:flutter/foundation.dart';

class RecipesParameterProvider extends ChangeNotifier {
  //for allergies

//ends allergies
}